const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = (() => { try { return require('better-sqlite3-session-store')(session); } catch { return null; } })();
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'exam-saathi.sqlite');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS students (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT DEFAULT '',
 description TEXT DEFAULT '', duration_minutes INTEGER NOT NULL DEFAULT 30,
 marks_per_question REAL NOT NULL DEFAULT 1, negative_marks REAL NOT NULL DEFAULT 0,
 published INTEGER NOT NULL DEFAULT 0, source_type TEXT NOT NULL DEFAULT 'database',
 html_path TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS questions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, test_id INTEGER NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
 position INTEGER NOT NULL, prompt TEXT NOT NULL, options_json TEXT NOT NULL,
 correct_index INTEGER NOT NULL, explanation TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS results (
 id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER REFERENCES students(id),
 student_name TEXT NOT NULL, test_id INTEGER NOT NULL, test_title TEXT NOT NULL,
 score REAL NOT NULL, max_score REAL NOT NULL, correct INTEGER NOT NULL, wrong INTEGER NOT NULL,
 skipped INTEGER NOT NULL, attempted INTEGER NOT NULL, percentage REAL NOT NULL,
 answers_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_results_student ON results(student_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_results_test ON results(test_id, created_at DESC);
`);

const adminName = process.env.ADMIN_USERNAME || 'admin';
const adminPass = process.env.ADMIN_PASSWORD || 'change-this-before-deploying';
const existingAdmin = db.prepare('SELECT id FROM admins WHERE username=?').get(adminName);
if (!existingAdmin) db.prepare('INSERT INTO admins(username,password_hash) VALUES(?,?)').run(adminName, bcrypt.hashSync(adminPass, 12));

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
 name: 'exam_saathi.sid',
 secret: process.env.SESSION_SECRET || 'development-only-change-this-secret-before-deploy',
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000*60*60*12 }
}));
app.use(express.static(path.join(__dirname, 'public')));

function requireStudent(req,res,next){ if(req.session.student) return next(); return res.status(401).json({error:'Please log in as a student.'}); }
function requireAdmin(req,res,next){ if(req.session.admin) return next(); return res.status(401).json({error:'Admin login required.'}); }
function cleanQuestion(q,i){
 const options = Array.isArray(q.options) ? q.options.map(x=>String(x).trim()).filter(Boolean) : [];
 if(!String(q.prompt||'').trim() || options.length<2) throw new Error(`Question ${i+1}: prompt and at least two options are required.`);
 const ci = Number(q.correctIndex);
 if(!Number.isInteger(ci)||ci<0||ci>=options.length) throw new Error(`Question ${i+1}: select a valid correct answer.`);
 return {prompt:String(q.prompt).trim(), options, correctIndex:ci, explanation:String(q.explanation||'').trim()};
}
function testFull(id){
 const test=db.prepare('SELECT * FROM tests WHERE id=?').get(id);
 if(!test) return null;
 const questions=db.prepare('SELECT id,position,prompt,options_json,correct_index,explanation FROM questions WHERE test_id=? ORDER BY position,id').all(id);
 return {...test, questions:questions.map(q=>({id:q.id,position:q.position,prompt:q.prompt,options:JSON.parse(q.options_json),correctIndex:q.correct_index,explanation:q.explanation||''}))};
}
function publicTest(t){ return {id:t.id,title:t.title,subject:t.subject,description:t.description,durationMinutes:t.duration_minutes,marksPerQuestion:t.marks_per_question,negativeMarks:t.negative_marks,questionCount:t.questions.length}; }

app.get('/api/me',(req,res)=>res.json({student:req.session.student||null,admin:req.session.admin||null}));
app.post('/api/register', async (req,res)=>{
 try {
  const name=String(req.body.name||'').trim(), username=String(req.body.username||'').trim().toLowerCase(), password=String(req.body.password||'');
  if(name.length<2||username.length<3||!/^[a-z0-9_.-]+$/.test(username)||password.length<8) return res.status(400).json({error:'Enter a name, username (3+ letters/numbers), and password (at least 8 characters).'});
  const hash=await bcrypt.hash(password,12);
  const result=db.prepare('INSERT INTO students(name,username,password_hash) VALUES(?,?,?)').run(name,username,hash);
  req.session.student={id:Number(result.lastInsertRowid),name,username};
  res.json({ok:true,student:req.session.student});
 } catch(e){ res.status(400).json({error:e.code==='SQLITE_CONSTRAINT_UNIQUE'?'That username is already taken.':'Could not create account.'}); }
});
app.post('/api/login', async (req,res)=>{
 const username=String(req.body.username||'').trim().toLowerCase(), password=String(req.body.password||'');
 const student=db.prepare('SELECT * FROM students WHERE username=?').get(username);
 if(!student||!(await bcrypt.compare(password,student.password_hash))) return res.status(401).json({error:'Incorrect username or password.'});
 req.session.student={id:student.id,name:student.name,username:student.username}; res.json({ok:true,student:req.session.student});
});
app.post('/api/admin/login', async (req,res)=>{
 const username=String(req.body.username||''), password=String(req.body.password||'');
 const admin=db.prepare('SELECT * FROM admins WHERE username=?').get(username);
 if(!admin||!(await bcrypt.compare(password,admin.password_hash))) return res.status(401).json({error:'Incorrect admin credentials.'});
 req.session.admin={id:admin.id,username:admin.username}; res.json({ok:true,admin:req.session.admin});
});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.post('/api/admin/change-password',requireAdmin,async(req,res)=>{
 const old=String(req.body.oldPassword||''), next=String(req.body.newPassword||'');
 const admin=db.prepare('SELECT * FROM admins WHERE id=?').get(req.session.admin.id);
 if(!admin||!(await bcrypt.compare(old,admin.password_hash))) return res.status(400).json({error:'Current password is incorrect.'});
 if(next.length<12) return res.status(400).json({error:'New admin password must be at least 12 characters.'});
 db.prepare('UPDATE admins SET password_hash=? WHERE id=?').run(await bcrypt.hash(next,12),admin.id); res.json({ok:true});
});

app.get('/api/tests',requireStudent,(req,res)=>{
 const tests=db.prepare("SELECT * FROM tests WHERE published=1 ORDER BY created_at DESC").all();
 res.json(tests.map(t=>({...t,questions:db.prepare('SELECT id FROM questions WHERE test_id=?').all(t.id)})).map(t=>({id:t.id,title:t.title,subject:t.subject,description:t.description,durationMinutes:t.duration_minutes,questionCount:t.questions.length})));
});
app.get('/api/tests/:id',requireStudent,(req,res)=>{
 const t=testFull(Number(req.params.id)); if(!t||!t.published) return res.status(404).json({error:'Test not found.'});
 res.json({...publicTest(t),questions:t.questions.map(q=>({id:q.id,prompt:q.prompt,options:q.options}))});
});
app.post('/api/tests/:id/submit',requireStudent,(req,res)=>{
 const t=testFull(Number(req.params.id)); if(!t||!t.published) return res.status(404).json({error:'Test not found.'});
 const given=req.body.answers||{}; let correct=0,wrong=0,skipped=0,attempted=0,score=0;
 const details=t.questions.map(q=>{
  const raw=given[q.id]; const answered=raw!==undefined&&raw!==null&&raw!=='';
  let selectedIndex=answered?Number(raw):null; const valid=answered&&Number.isInteger(selectedIndex)&&selectedIndex>=0&&selectedIndex<q.options.length;
  if(!valid){skipped++;selectedIndex=null;} else {attempted++;if(selectedIndex===q.correctIndex){correct++;score+=Number(t.marks_per_question);}else{wrong++;score-=Number(t.negative_marks);}}
  return {questionId:q.id,prompt:q.prompt,options:q.options,selectedIndex,selectedAnswer:selectedIndex===null?null:q.options[selectedIndex],correctIndex:q.correctIndex,correctAnswer:q.options[q.correctIndex],isCorrect:valid&&selectedIndex===q.correctIndex,skipped:!valid,explanation:q.explanation};
 });
 const maxScore=t.questions.length*Number(t.marks_per_question); const percentage=maxScore>0?Math.max(0,score)/maxScore*100:0;
 const info={score:Number(score.toFixed(2)),maxScore:Number(maxScore.toFixed(2)),correct,wrong,skipped,attempted,percentage:Number(percentage.toFixed(2)),details};
 const ins=db.prepare(`INSERT INTO results(student_id,student_name,test_id,test_title,score,max_score,correct,wrong,skipped,attempted,percentage,answers_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(req.session.student.id,req.session.student.name,t.id,t.title,info.score,info.maxScore,correct,wrong,skipped,attempted,info.percentage,JSON.stringify(details));
 const rank=db.prepare('SELECT COUNT(*)+1 AS rank FROM results WHERE test_id=? AND (score>? OR (score=? AND created_at<?))').get(t.id,info.score,info.score,new Date().toISOString()).rank;
 res.json({ok:true,resultId:Number(ins.lastInsertRowid),testId:t.id,rank,...info});
});
app.get('/api/my-results',requireStudent,(req,res)=>{
 const rows=db.prepare('SELECT id,test_id,test_title,score,max_score,correct,wrong,skipped,attempted,percentage,created_at FROM results WHERE student_id=? ORDER BY created_at DESC').all(req.session.student.id);
 res.json(rows);
});
app.get('/api/my-results/:id',requireStudent,(req,res)=>{
 const r=db.prepare('SELECT * FROM results WHERE id=? AND student_id=?').get(Number(req.params.id),req.session.student.id);
 if(!r)return res.status(404).json({error:'Result not found.'});
 res.json({...r,details:JSON.parse(r.answers_json)});
});
app.get('/api/tests/:id/leaderboard',requireStudent,(req,res)=>{
 res.json(db.prepare('SELECT student_name,score,max_score,percentage,created_at FROM results WHERE test_id=? ORDER BY score DESC,created_at ASC LIMIT 10').all(Number(req.params.id)));
});

app.get('/api/admin/tests',requireAdmin,(req,res)=>{
 const tests=db.prepare('SELECT * FROM tests ORDER BY updated_at DESC').all();
 res.json(tests.map(t=>({...t,questions:db.prepare('SELECT id FROM questions WHERE test_id=?').all(t.id)})).map(t=>({id:t.id,title:t.title,subject:t.subject,description:t.description,durationMinutes:t.duration_minutes,marksPerQuestion:t.marks_per_question,negativeMarks:t.negative_marks,published:!!t.published,sourceType:t.source_type,questionCount:t.questions.length,updatedAt:t.updated_at})));
});
app.get('/api/admin/tests/:id',requireAdmin,(req,res)=>{
 const t=testFull(Number(req.params.id)); if(!t)return res.status(404).json({error:'Test not found.'});
 res.json({...t,published:!!t.published,durationMinutes:t.duration_minutes,marksPerQuestion:t.marks_per_question,negativeMarks:t.negative_marks});
});
app.post('/api/admin/tests',requireAdmin,(req,res)=>{
 try{
  const b=req.body; const title=String(b.title||'').trim(); const qs=Array.isArray(b.questions)?b.questions.map(cleanQuestion):[];
  if(!title||!qs.length) return res.status(400).json({error:'Test title and at least one question are required.'});
  const tx=db.transaction(()=>{
   const id=Number(db.prepare('INSERT INTO tests(title,subject,description,duration_minutes,marks_per_question,negative_marks,published) VALUES(?,?,?,?,?,?,?)').run(title,String(b.subject||''),String(b.description||''),Math.max(1,Number(b.durationMinutes)||30),Math.max(0,Number(b.marksPerQuestion)||1),Math.max(0,Number(b.negativeMarks)||0),b.published?1:0).lastInsertRowid);
   const insert=db.prepare('INSERT INTO questions(test_id,position,prompt,options_json,correct_index,explanation) VALUES(?,?,?,?,?,?)');
   qs.forEach((q,i)=>insert.run(id,i+1,q.prompt,JSON.stringify(q.options),q.correctIndex,q.explanation)); return id;
  }); res.json({ok:true,id:tx()});
 }catch(e){res.status(400).json({error:e.message||'Could not create test.'});}
});
app.put('/api/admin/tests/:id',requireAdmin,(req,res)=>{
 try{
  const id=Number(req.params.id), b=req.body, title=String(b.title||'').trim(), qs=Array.isArray(b.questions)?b.questions.map(cleanQuestion):[];
  if(!db.prepare('SELECT id FROM tests WHERE id=?').get(id))return res.status(404).json({error:'Test not found.'});
  if(!title||!qs.length)return res.status(400).json({error:'Title and at least one question are required.'});
  const tx=db.transaction(()=>{
   db.prepare("UPDATE tests SET title=?,subject=?,description=?,duration_minutes=?,marks_per_question=?,negative_marks=?,published=?,updated_at=datetime('now') WHERE id=?").run(title,String(b.subject||''),String(b.description||''),Math.max(1,Number(b.durationMinutes)||30),Math.max(0,Number(b.marksPerQuestion)||1),Math.max(0,Number(b.negativeMarks)||0),b.published?1:0,id);
   db.prepare('DELETE FROM questions WHERE test_id=?').run(id);
   const insert=db.prepare('INSERT INTO questions(test_id,position,prompt,options_json,correct_index,explanation) VALUES(?,?,?,?,?,?)');
   qs.forEach((q,i)=>insert.run(id,i+1,q.prompt,JSON.stringify(q.options),q.correctIndex,q.explanation));
  }); tx(); res.json({ok:true});
 }catch(e){res.status(400).json({error:e.message||'Could not update test.'});}
});
app.delete('/api/admin/tests/:id',requireAdmin,(req,res)=>{
 const id=Number(req.params.id);
 if(!db.prepare('SELECT id FROM tests WHERE id=?').get(id))return res.status(404).json({error:'Test not found.'});
 // Historical result snapshots remain in results; deleting a test removes only the live test/questions.
 db.transaction(()=>{db.prepare('DELETE FROM questions WHERE test_id=?').run(id);db.prepare('DELETE FROM tests WHERE id=?').run(id);})();
 res.json({ok:true});
});
app.get('/api/admin/results',requireAdmin,(req,res)=>{
 res.json(db.prepare('SELECT r.id,r.student_id,r.student_name,r.test_id,r.test_title,r.score,r.max_score,r.correct,r.wrong,r.skipped,r.attempted,r.percentage,r.created_at,s.username FROM results r LEFT JOIN students s ON s.id=r.student_id ORDER BY r.created_at DESC LIMIT 1000').all());
});
app.get('/api/admin/results/:id',requireAdmin,(req,res)=>{
 const r=db.prepare('SELECT * FROM results WHERE id=?').get(Number(req.params.id));
 if(!r)return res.status(404).json({error:'Result not found.'});
 res.json({...r,details:JSON.parse(r.answers_json)});
});
app.get('/api/admin/students',requireAdmin,(req,res)=>{
 res.json(db.prepare(`SELECT s.id,s.name,s.username,s.created_at,COUNT(r.id) AS attempts,ROUND(AVG(r.percentage),2) AS average_percentage FROM students s LEFT JOIN results r ON r.student_id=s.id GROUP BY s.id ORDER BY s.created_at DESC`).all());
});
app.get('/api/admin/students/:id/results',requireAdmin,(req,res)=>{
 res.json(db.prepare('SELECT id,test_title,score,max_score,correct,wrong,skipped,attempted,percentage,created_at FROM results WHERE student_id=? ORDER BY created_at DESC').all(Number(req.params.id)));
});
app.get('/api/admin/leaderboard/:testId',requireAdmin,(req,res)=>{
 res.json(db.prepare('SELECT student_name,score,max_score,percentage,created_at FROM results WHERE test_id=? ORDER BY score DESC,created_at ASC LIMIT 10').all(Number(req.params.testId)));
});

// Standalone HTML files are discoverable for legacy compatibility. For student-specific scoring,
// convert/import their questions into the built-in test format; generic HTML cannot be scored safely
// without a defined answer-data contract.
app.get('/api/html-tests',requireStudent,(req,res)=>{
 const dirs=[path.join(__dirname,'public','tests'),path.join(__dirname,'tests')], out=[];
 for(const dir of dirs){if(fs.existsSync(dir)) for(const f of fs.readdirSync(dir).filter(x=>x.endsWith('.html'))){out.push({title:f.replace(/\.html$/i,'').replace(/[-_]/g,' '),url:dir.startsWith(path.join(__dirname,'public'))?'/tests/'+encodeURIComponent(f):'/legacy-tests/'+encodeURIComponent(f),legacy:true});}}
 res.json(out);
});
app.use('/legacy-tests',express.static(path.join(__dirname,'tests')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Exam Saathi running on port ${PORT}`));
